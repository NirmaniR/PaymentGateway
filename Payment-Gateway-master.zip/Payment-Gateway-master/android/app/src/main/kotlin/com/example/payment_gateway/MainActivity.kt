package com.example.payment_gateway

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
